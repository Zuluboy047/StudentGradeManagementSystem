package icetasks2;

import javax.swing.JOptionPane;

public class ICETASKS2 {
 
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hi, Boipelo Nxumalo, Welcome to Rosebank College","Welcome Message",JOptionPane.INFORMATION_MESSAGE);
        
    }
    
}
