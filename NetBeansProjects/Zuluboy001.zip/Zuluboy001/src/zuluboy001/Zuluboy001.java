/*
 My first project
multi-line commet
 */
package zuluboy001;//this is the package of my project

public class Zuluboy001 {

    public static void main(String[] args) {
      System.out.println("2025 ");
      System.out.println("Zuluboy!");
      System.out.println("My name is Zuluboy.");
      System.out.println("12345678910");
    }
}
